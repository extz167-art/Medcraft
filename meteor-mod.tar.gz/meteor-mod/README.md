# ☄ Meteor Mod — NeoForge 1.21.1

Periodic meteor impacts inspired by Terraria. Meteors spawn near players, leave
craters, and are filled with mineable ore (iron blocks by default, easily swapped).

## Features

- **Periodic meteor spawns** — configurable interval and probability
- **Realistic craters** — parabolic bowl with scorched floor, scattered debris
- **Irregular meteor shape** — lumpy oblate sphere with crust + core, not a perfect ball
- **Base protection** — heuristic scan for player-placed blocks, respawn distance checks
- **Admin command** — `/meteor summon <x> <y> <z> [radius]` and `/meteor summonhere [radius]`
- **Chat announcements** — optional broadcast with coordinates
- **Fully configurable** — every tunable in `meteormod-server.toml`

## Building

Requires Java 21.

```bash
./gradlew build
```

The mod JAR will be in `build/libs/`.

## Commands

| Command | Permission | Description |
|---|---|---|
| `/meteor summon <pos>` | OP 2 | Summon a meteor at coordinates (random radius) |
| `/meteor summon <pos> <radius>` | OP 2 | Summon with specific radius (2–15) |
| `/meteor summonhere` | OP 2 | Summon at your feet |
| `/meteor summonhere <radius>` | OP 2 | Summon at your feet with specific radius |

## Configuration

Generated at `world/serverconfig/meteormod-server.toml` after first run.

### Spawning
| Key | Default | Description |
|---|---|---|
| `spawnIntervalTicks` | 6000 (5 min) | Ticks between spawn attempts |
| `spawnChance` | 3 | 1-in-N chance per attempt |

### Placement
| Key | Default | Description |
|---|---|---|
| `minDistanceFromPlayer` | 100 | Minimum blocks from any player |
| `maxDistanceFromPlayer` | 500 | Max blocks from anchor player |
| `minRadius` | 3 | Smallest meteor |
| `maxRadius` | 6 | Largest meteor |

### Base Protection
| Key | Default | Description |
|---|---|---|
| `minDistanceFromSpawn` | 64 | Min blocks from beds / world spawn |
| `baseBlockThreshold` | 8 | Player-block count that triggers re-roll |
| `baseScanRadius` | 12 | Area scanned for player blocks |
| `maxRetries` | 10 | Re-rolls before giving up |

### Effects
| Key | Default | Description |
|---|---|---|
| `announceInChat` | true | Broadcast impact in chat |
| `playSound` | true | Play explosion sound |

## Changing the Meteor Block

Open `MeteorPlacer.java` and change the constants at the top:

```java
// Vanilla block:
public static BlockState METEOR_BLOCK = Blocks.DIAMOND_BLOCK.defaultBlockState();

// Or a custom registered block:
public static BlockState METEOR_BLOCK = ModBlocks.METEORITE_ORE.get().defaultBlockState();
```

To register a custom block, uncomment the `METEORITE_ORE` section in `ModBlocks.java`.

You can also change `METEOR_CRUST` (outer shell), `SCORCHED_BLOCK` (crater floor),
and `DEBRIS_BLOCK` (rim scatter) the same way.

## Architecture

```
MeteorMod.java           — Entry point, event registration
├── config/
│   └── MeteorConfig     — All server config values
├── block/
│   └── ModBlocks        — Block/item registration (custom ore ready)
├── command/
│   └── MeteorCommand    — /meteor summon commands
├── event/
│   └── MeteorSpawnHandler — Tick-based periodic spawning
└── util/
    ├── MeteorPlacer     — Crater carving + meteor body placement
    └── BaseDetector     — Player-base heuristic detection
```
