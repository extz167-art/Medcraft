package com.meteormod.block;

import com.meteormod.MeteorMod;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModBlocks {

    public static final DeferredRegister.Blocks BLOCKS =
            DeferredRegister.createBlocks(MeteorMod.MODID);

    public static final DeferredRegister.Items ITEMS =
            DeferredRegister.createItems(MeteorMod.MODID);

    // ═══════════════════════════════════════════════════════════════
    //  METEOR BLOCK — Change this to swap what the meteor is made of.
    //  For a custom block, register one here. For vanilla, see
    //  MeteorPlacer.METEOR_BLOCK which defaults to Blocks.IRON_BLOCK.
    // ═══════════════════════════════════════════════════════════════

    /**
     * Example custom meteorite ore block (commented out — enable if you
     * want a unique block instead of vanilla iron blocks).
     *
     * Uncomment these and set MeteorPlacer.METEOR_BLOCK to
     * METEORITE_ORE.get().defaultBlockState()
     */
    /*
    public static final DeferredBlock<Block> METEORITE_ORE = BLOCKS.register(
            "meteorite_ore",
            () -> new Block(BlockBehaviour.Properties.ofFullCopy(Blocks.IRON_ORE)
                    .strength(4.0f, 6.0f)
                    .sound(SoundType.STONE)
                    .requiresCorrectToolForDrops())
    );

    public static final DeferredItem<BlockItem> METEORITE_ORE_ITEM = ITEMS.register(
            "meteorite_ore",
            () -> new BlockItem(METEORITE_ORE.get(), new Item.Properties())
    );
    */

    public static void register(IEventBus modEventBus) {
        BLOCKS.register(modEventBus);
        ITEMS.register(modEventBus);
    }
}
