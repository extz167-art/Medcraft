package com.meteormod.event;

import com.meteormod.MeteorMod;
import com.meteormod.config.MeteorConfig;
import com.meteormod.util.BaseDetector;
import com.meteormod.util.MeteorPlacer;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

import java.util.List;
import java.util.Random;

public class MeteorSpawnHandler {

    private static int tickCounter = 0;
    private static final Random RANDOM = new Random();

    public static void onServerTick(MinecraftServer server) {
        tickCounter++;

        int interval = MeteorConfig.SPAWN_INTERVAL_TICKS.get();
        if (tickCounter < interval) return;
        tickCounter = 0;

        // Roll the dice
        int chance = MeteorConfig.SPAWN_CHANCE.get();
        if (RANDOM.nextInt(chance) != 0) return;

        // Need at least one player online
        ServerLevel overworld = server.overworld();
        List<ServerPlayer> players = overworld.players();
        if (players.isEmpty()) return;

        // Pick a random player as the anchor
        ServerPlayer anchor = players.get(RANDOM.nextInt(players.size()));

        int minDist = MeteorConfig.MIN_DISTANCE_FROM_PLAYER.get();
        int maxDist = MeteorConfig.MAX_DISTANCE_FROM_PLAYER.get();
        int maxRetries = MeteorConfig.MAX_RETRIES.get();

        for (int attempt = 0; attempt < maxRetries; attempt++) {
            // Random angle and distance from the anchor player
            double angle = RANDOM.nextDouble() * Math.PI * 2;
            int distance = minDist + RANDOM.nextInt(maxDist - minDist + 1);

            int targetX = (int) (anchor.getX() + Math.cos(angle) * distance);
            int targetZ = (int) (anchor.getZ() + Math.sin(angle) * distance);

            // ── Validation checks ─────────────────────────────────
            // 1. Is the chunk loaded? (don't force-load)
            if (!overworld.isLoaded(new BlockPos(targetX, 64, targetZ))) {
                continue;
            }

            // 2. Too close to any player right now?
            boolean tooCloseToPlayer = false;
            for (ServerPlayer p : players) {
                double dx = targetX - p.getX();
                double dz = targetZ - p.getZ();
                if (dx * dx + dz * dz < minDist * minDist) {
                    tooCloseToPlayer = true;
                    break;
                }
            }
            if (tooCloseToPlayer) continue;

            // 3. Near a respawn point?
            if (BaseDetector.isNearRespawn(overworld, targetX, targetZ)) {
                continue;
            }

            // 4. Player base detected?
            if (BaseDetector.isNearBase(overworld, targetX, targetZ)) {
                MeteorMod.LOGGER.debug("Meteor site ({}, {}) rejected: base detected", targetX, targetZ);
                continue;
            }

            // ── All clear — place the meteor ──────────────────────
            int minR = MeteorConfig.MIN_RADIUS.get();
            int maxR = MeteorConfig.MAX_RADIUS.get();
            int radius = minR + RANDOM.nextInt(maxR - minR + 1);

            BlockPos placed = MeteorPlacer.placeAtSurface(overworld, targetX, targetZ, radius);
            if (placed != null) {
                MeteorMod.LOGGER.info("Meteor landed at ({}, {}, {}), radius {}",
                        placed.getX(), placed.getY(), placed.getZ(), radius);

                if (MeteorConfig.ANNOUNCE_IN_CHAT.get()) {
                    server.getPlayerList().broadcastSystemMessage(
                            Component.literal("§6§l☄ A meteor has crashed nearby! §r§7[" +
                                    placed.getX() + ", " + placed.getZ() + "]"),
                            false
                    );
                }
                return; // success
            }
        }

        MeteorMod.LOGGER.debug("Meteor spawn failed after {} retries", maxRetries);
    }
}
