package com.meteormod.config;

import net.neoforged.neoforge.common.ModConfigSpec;

public class MeteorConfig {

    public static final ModConfigSpec SPEC;

    // ── Spawn Timing ──────────────────────────────────────────────
    /** How often (in ticks) to attempt a meteor spawn. 20 ticks = 1 second. */
    public static final ModConfigSpec.IntValue SPAWN_INTERVAL_TICKS;

    /** Chance (1 in N) that a meteor actually spawns each interval. */
    public static final ModConfigSpec.IntValue SPAWN_CHANCE;

    // ── Placement ─────────────────────────────────────────────────
    /** Minimum distance (blocks) from any player for meteor placement. */
    public static final ModConfigSpec.IntValue MIN_DISTANCE_FROM_PLAYER;

    /** Maximum distance (blocks) from a random player to look for a landing site. */
    public static final ModConfigSpec.IntValue MAX_DISTANCE_FROM_PLAYER;

    /** Minimum meteor radius (blocks). */
    public static final ModConfigSpec.IntValue MIN_RADIUS;

    /** Maximum meteor radius (blocks). */
    public static final ModConfigSpec.IntValue MAX_RADIUS;

    // ── Base Protection ───────────────────────────────────────────
    /** Minimum distance (blocks) from any player's spawn point / bed. */
    public static final ModConfigSpec.IntValue MIN_DISTANCE_FROM_SPAWN;

    /**
     * Max number of "player-placed" blocks detected in the landing zone
     * before we abort and re-roll. Prevents landing on bases.
     */
    public static final ModConfigSpec.IntValue BASE_BLOCK_THRESHOLD;

    /** Radius around the impact site to scan for player-placed blocks. */
    public static final ModConfigSpec.IntValue BASE_SCAN_RADIUS;

    /** Maximum re-rolls when a site fails the base-detection check. */
    public static final ModConfigSpec.IntValue MAX_RETRIES;

    // ── Crater ────────────────────────────────────────────────────
    /** Depth multiplier for the crater bowl relative to the meteor radius. */
    public static final ModConfigSpec.DoubleValue CRATER_DEPTH_MULTIPLIER;

    /** Whether to scatter debris blocks around the crater rim. */
    public static final ModConfigSpec.BooleanValue SCATTER_DEBRIS;

    // ── Effects ───────────────────────────────────────────────────
    /** Whether to announce meteor impacts in chat. */
    public static final ModConfigSpec.BooleanValue ANNOUNCE_IN_CHAT;

    /** Whether to play explosion sound on impact. */
    public static final ModConfigSpec.BooleanValue PLAY_SOUND;

    static {
        ModConfigSpec.Builder builder = new ModConfigSpec.Builder();

        builder.comment("Meteor Spawn Settings").push("spawning");
        SPAWN_INTERVAL_TICKS = builder
                .comment("Ticks between spawn attempts (6000 = 5 minutes)")
                .defineInRange("spawnIntervalTicks", 6000, 200, 72000);
        SPAWN_CHANCE = builder
                .comment("1-in-N chance per interval (higher = rarer)")
                .defineInRange("spawnChance", 3, 1, 100);
        builder.pop();

        builder.comment("Placement Settings").push("placement");
        MIN_DISTANCE_FROM_PLAYER = builder
                .comment("Minimum blocks from any player")
                .defineInRange("minDistanceFromPlayer", 100, 32, 1000);
        MAX_DISTANCE_FROM_PLAYER = builder
                .comment("Maximum blocks from a random player")
                .defineInRange("maxDistanceFromPlayer", 500, 64, 2000);
        MIN_RADIUS = builder
                .comment("Minimum meteor radius")
                .defineInRange("minRadius", 3, 2, 10);
        MAX_RADIUS = builder
                .comment("Maximum meteor radius")
                .defineInRange("maxRadius", 6, 3, 15);
        builder.pop();

        builder.comment("Base Protection").push("protection");
        MIN_DISTANCE_FROM_SPAWN = builder
                .comment("Minimum blocks from any bed / world spawn")
                .defineInRange("minDistanceFromSpawn", 64, 0, 500);
        BASE_BLOCK_THRESHOLD = builder
                .comment("Max player-placed blocks allowed in landing zone before re-roll")
                .defineInRange("baseBlockThreshold", 8, 1, 50);
        BASE_SCAN_RADIUS = builder
                .comment("Radius to scan for player-placed blocks")
                .defineInRange("baseScanRadius", 12, 4, 32);
        MAX_RETRIES = builder
                .comment("Max location re-rolls before giving up")
                .defineInRange("maxRetries", 10, 1, 50);
        builder.pop();

        builder.comment("Crater Shape").push("crater");
        CRATER_DEPTH_MULTIPLIER = builder
                .comment("Crater depth as a fraction of radius (1.0 = hemisphere)")
                .defineInRange("craterDepthMultiplier", 0.7, 0.3, 2.0);
        SCATTER_DEBRIS = builder
                .comment("Scatter debris blocks around the rim")
                .define("scatterDebris", true);
        builder.pop();

        builder.comment("Effects").push("effects");
        ANNOUNCE_IN_CHAT = builder
                .comment("Announce meteor impacts in server chat")
                .define("announceInChat", true);
        PLAY_SOUND = builder
                .comment("Play explosion sound on impact")
                .define("playSound", true);
        builder.pop();

        SPEC = builder.build();
    }
}
