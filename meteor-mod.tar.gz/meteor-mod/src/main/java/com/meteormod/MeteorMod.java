package com.meteormod;

import com.meteormod.block.ModBlocks;
import com.meteormod.command.MeteorCommand;
import com.meteormod.config.MeteorConfig;
import com.meteormod.event.MeteorSpawnHandler;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Mod(MeteorMod.MODID)
public class MeteorMod {
    public static final String MODID = "meteormod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MeteorMod.MODID);

    public MeteorMod(IEventBus modEventBus, ModContainer modContainer) {
        LOGGER.info("MeteorMod initializing...");

        // Register blocks and items on the mod bus
        ModBlocks.register(modEventBus);

        // Register server config
        modContainer.registerConfig(ModConfig.Type.SERVER, MeteorConfig.SPEC, "meteormod-server.toml");

        // Register event handlers on the game bus
        NeoForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onServerTick(ServerTickEvent.Post event) {
        MeteorSpawnHandler.onServerTick(event.getServer());
    }

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        MeteorCommand.register(event.getDispatcher());
    }
}
