package com.meteormod.util;

import com.meteormod.MeteorMod;
import com.meteormod.config.MeteorConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.Random;

public class MeteorPlacer {

    // ═══════════════════════════════════════════════════════════════
    //  CHANGE THIS to swap the block the meteor is made of.
    //  Examples:
    //    Blocks.DIAMOND_BLOCK.defaultBlockState()
    //    Blocks.OBSIDIAN.defaultBlockState()
    //    ModBlocks.METEORITE_ORE.get().defaultBlockState()  (if custom)
    // ═══════════════════════════════════════════════════════════════
    public static BlockState METEOR_BLOCK = Blocks.IRON_BLOCK.defaultBlockState();

    /** Secondary block used for the outer shell / crust of the meteor. */
    public static BlockState METEOR_CRUST = Blocks.DEEPSLATE.defaultBlockState();

    /** Block placed at the very bottom of the crater (scorched ground). */
    public static BlockState SCORCHED_BLOCK = Blocks.BLACKSTONE.defaultBlockState();

    /** Debris scattered around the rim. */
    public static BlockState DEBRIS_BLOCK = Blocks.COBBLESTONE.defaultBlockState();

    private static final Random RANDOM = new Random();

    /**
     * Place a meteor and crater at the given X/Z, finding the surface Y
     * automatically.
     *
     * @return the actual center BlockPos of the placed meteor, or null if
     *         the position was unsuitable (void, out of world, etc.)
     */
    public static BlockPos placeAtSurface(ServerLevel level, int x, int z, int radius) {
        // Find surface
        int surfaceY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
        if (surfaceY <= level.getMinBuildHeight() + 5) {
            return null; // void or bedrock-only column
        }

        // Meteor center sits partially above surface, partially embedded
        int embedDepth = Math.max(1, radius / 2);
        BlockPos center = new BlockPos(x, surfaceY - embedDepth, z);

        placeMeteor(level, center, radius);
        return center;
    }

    /**
     * Place the full meteor structure: crater bowl + meteor body.
     */
    public static void placeMeteor(ServerLevel level, BlockPos center, int radius) {
        int craterRadius = radius + 3;                                       // crater is wider than the rock
        double depthMult = MeteorConfig.CRATER_DEPTH_MULTIPLIER.get();
        int craterDepth = Math.max(2, (int) (craterRadius * depthMult));
        boolean scatter = MeteorConfig.SCATTER_DEBRIS.get();

        MeteorMod.LOGGER.info("Placing meteor at {} with radius {} (crater radius {}, depth {})",
                center, radius, craterRadius, craterDepth);

        // ── Phase 1: Carve the crater ─────────────────────────────
        carveCrater(level, center, craterRadius, craterDepth);

        // ── Phase 2: Place the meteor body ────────────────────────
        placeMeteorBody(level, center, radius);

        // ── Phase 3: Scatter rim debris ───────────────────────────
        if (scatter) {
            scatterDebris(level, center, craterRadius);
        }

        // ── Phase 4: Effects ──────────────────────────────────────
        if (MeteorConfig.PLAY_SOUND.get()) {
            level.playSound(null, center, SoundEvents.GENERIC_EXPLODE.value(),
                    SoundSource.BLOCKS, 4.0f, 0.8f + RANDOM.nextFloat() * 0.4f);
        }
        // Spawn particles
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER,
                center.getX(), center.getY() + radius, center.getZ(),
                5, radius, radius, radius, 0.1);
        level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE,
                center.getX(), center.getY() + radius, center.getZ(),
                40, radius * 1.5, radius, radius * 1.5, 0.02);
    }

    // ──────────────────────────────────────────────────────────────
    //  Crater: a paraboloid bowl carved into the terrain
    // ──────────────────────────────────────────────────────────────
    private static void carveCrater(ServerLevel level, BlockPos center, int craterRadius, int craterDepth) {
        for (int dx = -craterRadius; dx <= craterRadius; dx++) {
            for (int dz = -craterRadius; dz <= craterRadius; dz++) {
                double horizDist = Math.sqrt(dx * dx + dz * dz);
                if (horizDist > craterRadius) continue;

                // Parabolic profile: deepest at center, zero at rim
                double normalizedDist = horizDist / craterRadius;
                int localDepth = (int) (craterDepth * (1.0 - normalizedDist * normalizedDist));
                if (localDepth <= 0) continue;

                // Remove blocks downward from surface to carve the bowl
                for (int dy = 3; dy >= -localDepth; dy--) {
                    BlockPos pos = center.offset(dx, dy, dz);
                    BlockState existing = level.getBlockState(pos);
                    if (!existing.isAir() && existing.getDestroySpeed(level, pos) >= 0) {
                        level.setBlockAndUpdate(pos, Blocks.AIR.defaultBlockState());
                    }
                }

                // Scorched floor at the bottom of the crater
                BlockPos floorPos = center.offset(dx, -localDepth, dz);
                if (horizDist < craterRadius * 0.6) {
                    level.setBlockAndUpdate(floorPos, SCORCHED_BLOCK);
                }
            }
        }
    }

    // ──────────────────────────────────────────────────────────────
    //  Meteor body: irregular oblate sphere with crust + core
    // ──────────────────────────────────────────────────────────────
    private static void placeMeteorBody(ServerLevel level, BlockPos center, int radius) {
        // Stretch factors to make it non-perfectly-round
        double stretchX = 0.85 + RANDOM.nextDouble() * 0.3;  // 0.85 – 1.15
        double stretchY = 0.7 + RANDOM.nextDouble() * 0.2;   // 0.7  – 0.9  (flatter)
        double stretchZ = 0.85 + RANDOM.nextDouble() * 0.3;

        // Per-octant noise offsets for lumpy shape
        double[] octantNoise = new double[8];
        for (int i = 0; i < 8; i++) {
            octantNoise[i] = 0.75 + RANDOM.nextDouble() * 0.5; // 0.75 – 1.25
        }

        double coreThreshold = radius * 0.55; // inner core = ore

        for (int dx = -radius - 1; dx <= radius + 1; dx++) {
            for (int dy = -radius - 1; dy <= radius + 1; dy++) {
                for (int dz = -radius - 1; dz <= radius + 1; dz++) {
                    double sx = dx / stretchX;
                    double sy = dy / stretchY;
                    double sz = dz / stretchZ;
                    double dist = Math.sqrt(sx * sx + sy * sy + sz * sz);

                    // Pick octant for noise
                    int octant = ((dx >= 0) ? 4 : 0) | ((dy >= 0) ? 2 : 0) | ((dz >= 0) ? 1 : 0);
                    double effectiveRadius = radius * octantNoise[octant];

                    if (dist > effectiveRadius) continue;

                    BlockPos pos = center.offset(dx, dy, dz);

                    if (dist < coreThreshold) {
                        // Inner core: the valuable material
                        level.setBlockAndUpdate(pos, METEOR_BLOCK);
                    } else {
                        // Outer crust
                        level.setBlockAndUpdate(pos, METEOR_CRUST);
                    }
                }
            }
        }
    }

    // ──────────────────────────────────────────────────────────────
    //  Rim debris: scattered blocks around the crater edge
    // ──────────────────────────────────────────────────────────────
    private static void scatterDebris(ServerLevel level, BlockPos center, int craterRadius) {
        int debrisCount = craterRadius * 4;
        for (int i = 0; i < debrisCount; i++) {
            double angle = RANDOM.nextDouble() * Math.PI * 2;
            double dist = craterRadius + 1 + RANDOM.nextDouble() * 4;
            int dx = (int) (Math.cos(angle) * dist);
            int dz = (int) (Math.sin(angle) * dist);

            int surfaceY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                    center.getX() + dx, center.getZ() + dz);
            BlockPos debrisPos = new BlockPos(center.getX() + dx, surfaceY, center.getZ() + dz);

            // Only place on solid ground
            if (level.getBlockState(debrisPos).isAir() &&
                !level.getBlockState(debrisPos.below()).isAir()) {
                level.setBlockAndUpdate(debrisPos, DEBRIS_BLOCK);
            }
        }
    }
}
