package com.meteormod.util;

import com.meteormod.config.MeteorConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * Heuristics to avoid dropping meteors on player bases.
 */
public class BaseDetector {

    /**
     * Returns true if the area around (x, z) looks like a player base.
     */
    public static boolean isNearBase(ServerLevel level, int x, int z) {
        int scanRadius = MeteorConfig.BASE_SCAN_RADIUS.get();
        int threshold  = MeteorConfig.BASE_BLOCK_THRESHOLD.get();

        int playerBlockCount = 0;

        // Sample blocks in a grid pattern (every other block) for performance
        for (int dx = -scanRadius; dx <= scanRadius; dx += 2) {
            for (int dz = -scanRadius; dz <= scanRadius; dz += 2) {
                int sx = x + dx;
                int sz = z + dz;
                int surfaceY = level.getHeight(Heightmap.Types.MOTION_BLOCKING, sx, sz);

                // Check a column from surface down 6 blocks
                for (int dy = 0; dy >= -6; dy--) {
                    BlockPos pos = new BlockPos(sx, surfaceY + dy, sz);
                    BlockState state = level.getBlockState(pos);
                    if (isPlayerPlacedBlock(state)) {
                        playerBlockCount++;
                        if (playerBlockCount >= threshold) {
                            return true;
                        }
                    }
                }
            }
        }

        return false;
    }

    /**
     * Returns true if the given position is too close to any player's
     * respawn point (bed / respawn anchor) or the world spawn.
     */
    public static boolean isNearRespawn(ServerLevel level, int x, int z) {
        int minDist = MeteorConfig.MIN_DISTANCE_FROM_SPAWN.get();
        int minDistSq = minDist * minDist;

        // Check world spawn
        BlockPos spawn = level.getSharedSpawnPos();
        double dxSpawn = x - spawn.getX();
        double dzSpawn = z - spawn.getZ();
        if (dxSpawn * dxSpawn + dzSpawn * dzSpawn < minDistSq) {
            return true;
        }

        // Check each online player's respawn point
        for (ServerPlayer player : level.players()) {
            BlockPos respawn = player.getRespawnPosition();
            if (respawn != null) {
                double dx = x - respawn.getX();
                double dz = z - respawn.getZ();
                if (dx * dx + dz * dz < minDistSq) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Heuristic: blocks that are strong indicators of player construction.
     * This intentionally casts a wide net — false positives just mean
     * we re-roll, which is cheap.
     */
    private static boolean isPlayerPlacedBlock(BlockState state) {
        Block block = state.getBlock();

        // Obvious player-placed functional blocks
        if (block instanceof CraftingTableBlock) return true;
        if (block instanceof AbstractFurnaceBlock) return true;
        if (block instanceof ChestBlock) return true;
        if (block instanceof BedBlock) return true;
        if (block instanceof DoorBlock) return true;
        if (block instanceof TrapDoorBlock) return true;
        if (block instanceof TorchBlock) return true;
        if (block instanceof LanternBlock) return true;
        if (block instanceof AnvilBlock) return true;
        if (block instanceof EnchantingTableBlock) return true;
        if (block instanceof BrewingStandBlock) return true;
        if (block instanceof SignBlock) return true;
        if (block instanceof LadderBlock) return true;
        if (block instanceof FenceBlock) return true;
        if (block instanceof FenceGateBlock) return true;

        // Processed building materials
        if (state.is(BlockTags.PLANKS)) return true;
        if (state.is(BlockTags.WOOL)) return true;
        if (block instanceof GlassBlock || block instanceof StainedGlassBlock) return true;
        if (block instanceof SlabBlock) return true;
        if (block instanceof StairBlock) return true;

        // Rails, redstone components
        if (block instanceof RailBlock || block instanceof PoweredRailBlock) return true;
        if (block instanceof RedstoneTorchBlock) return true;
        if (block instanceof RepeaterBlock) return true;
        if (block instanceof ComparatorBlock) return true;

        return false;
    }
}
