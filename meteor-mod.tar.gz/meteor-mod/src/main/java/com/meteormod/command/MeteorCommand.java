package com.meteormod.command;

import com.meteormod.config.MeteorConfig;
import com.meteormod.util.MeteorPlacer;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.coordinates.BlockPosArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;

public class MeteorCommand {

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(
                Commands.literal("meteor")
                        .requires(src -> src.hasPermission(2)) // OP level 2+
                        .then(Commands.literal("summon")
                                // /meteor summon <pos>
                                .then(Commands.argument("pos", BlockPosArgument.blockPos())
                                        .executes(ctx -> {
                                            BlockPos pos = BlockPosArgument.getLoadedBlockPos(ctx, "pos");
                                            int minR = MeteorConfig.MIN_RADIUS.get();
                                            int maxR = MeteorConfig.MAX_RADIUS.get();
                                            int radius = minR + ctx.getSource().getLevel().random.nextInt(maxR - minR + 1);
                                            return summonMeteor(ctx.getSource(), pos, radius);
                                        })
                                        // /meteor summon <pos> <radius>
                                        .then(Commands.argument("radius", IntegerArgumentType.integer(2, 15))
                                                .executes(ctx -> {
                                                    BlockPos pos = BlockPosArgument.getLoadedBlockPos(ctx, "pos");
                                                    int radius = IntegerArgumentType.getInteger(ctx, "radius");
                                                    return summonMeteor(ctx.getSource(), pos, radius);
                                                })
                                        )
                                )
                        )
                        // /meteor summonhere [radius]
                        .then(Commands.literal("summonhere")
                                .executes(ctx -> {
                                    BlockPos pos = BlockPos.containing(ctx.getSource().getPosition());
                                    int minR = MeteorConfig.MIN_RADIUS.get();
                                    int maxR = MeteorConfig.MAX_RADIUS.get();
                                    int radius = minR + ctx.getSource().getLevel().random.nextInt(maxR - minR + 1);
                                    return summonMeteor(ctx.getSource(), pos, radius);
                                })
                                .then(Commands.argument("radius", IntegerArgumentType.integer(2, 15))
                                        .executes(ctx -> {
                                            BlockPos pos = BlockPos.containing(ctx.getSource().getPosition());
                                            int radius = IntegerArgumentType.getInteger(ctx, "radius");
                                            return summonMeteor(ctx.getSource(), pos, radius);
                                        })
                                )
                        )
        );
    }

    private static int summonMeteor(CommandSourceStack source, BlockPos pos, int radius) {
        ServerLevel level = source.getLevel();

        // Use surface placement (finds Y automatically)
        BlockPos placed = MeteorPlacer.placeAtSurface(level, pos.getX(), pos.getZ(), radius);

        if (placed != null) {
            source.sendSuccess(() -> Component.literal(
                    "§6☄ Meteor summoned at §f" + placed.getX() + ", " + placed.getY() + ", " + placed.getZ() +
                    " §6(radius " + radius + ")"
            ), true);

            // Also broadcast if configured
            if (MeteorConfig.ANNOUNCE_IN_CHAT.get()) {
                source.getServer().getPlayerList().broadcastSystemMessage(
                        Component.literal("§6§l☄ A meteor has crashed! §r§7[" +
                                placed.getX() + ", " + placed.getZ() + "]"),
                        false
                );
            }
            return 1;
        } else {
            source.sendFailure(Component.literal("§cFailed to place meteor — unsuitable location."));
            return 0;
        }
    }
}
